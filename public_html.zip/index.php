<?php

header("Location: public/");