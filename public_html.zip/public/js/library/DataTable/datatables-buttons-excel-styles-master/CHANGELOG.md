# DataTables Buttons Excel Styling - Changelog
## v1.2.0 - 15 September 2021
### Refactor
* Refactored code to use pure javascript for main cell selection instead of jQuery
* Cached cell references to write final styles in a single pass

### Other
* Created changelog file