<?php

$cDoc = '#BDD7EE';
$cAdm = '#00B050';
$cDir = '#00B0F0';
$cCaf = '#FFE699';
$cMen = '#8780cc';
$cSG = '#C6E0B4';
$cSeg = '#aaaaaa';
$cExt = '#eeeeee';
$cTarde = '#ff0000';
$cNovedad = '#fff000';
$cHead = '#C65911';

$cEDoc = 'BDD7EE';
$cEAdm = '00B050';
$cEDir = '00B0F0';
$cECaf = 'FFE699';
$cEMen = '8780cc';
$cESG = 'C6E0B4';
$cESeg = 'aaaaaa';
$cEExt = 'eeeeee';
$cETarde = 'ff0000';
$cENovedad = 'fff000';
$cEHead = 'C65911';