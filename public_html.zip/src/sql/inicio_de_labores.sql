

CREATE TABLE `inicio_de_labores` (
  `id` int(10) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `fecha` date NOT NULL
);
